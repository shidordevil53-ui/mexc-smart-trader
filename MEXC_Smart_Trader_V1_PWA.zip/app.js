const demo=[
 {symbol:"IOST/USDT",setup:"Breakout + Retest",score:86,status:"WATCH"},
 {symbol:"POWR/USDT",setup:"Long Base + Breakout",score:82,status:"WATCH"},
 {symbol:"NEAR/USDT",setup:"Trend + Momentum",score:76,status:"WATCH"}
];
function render(){
 const el=document.getElementById("results");
 el.innerHTML=demo.map(x=>`<div class="result">
 <div class="row"><strong>${x.symbol}</strong><span>${x.status}</span></div>
 <small>${x.setup}</small>
 <div class="row"><span>Score</span><span class="score">${x.score}/100</span></div>
 </div>`).join("");
}
document.getElementById("scan").onclick=()=>{
 document.getElementById("status").textContent="V1 prototype: menampilkan contoh hasil. Live MEXC belum diaktifkan.";
 render();
};
render();
